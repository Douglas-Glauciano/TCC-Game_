Descrição de cada sistema do jogo:
    Criação de personagem (raças, classes, atributos, antecedentes).
    Combate (turnos, cálculos, exemplos).
    Exploração (mapa, eventos aleatórios).
    NPCs (funções e papel no gameplay).
    Inventário e equipamentos.

Regras fixas do mundo (ex.: "O mal é absoluto").
Elementos “porque é legal” (explicar estética e absurdos propositais).
Referências de gameplay (comparações com jogos conhecidos).